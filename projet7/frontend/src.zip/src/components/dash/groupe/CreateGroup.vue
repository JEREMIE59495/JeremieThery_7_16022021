<!--Pop up pour ajouter un nouveau groupe-->
<template>
    <div v-if="visuGroup">
        <label for="createGroup">Nom du groupe :</label>
        <input type="text" id="createGroup" class="createGroup" v-model="name_group" >
        <button  type="submit" @click="addGroup">Enregistrer</button>
    </div>
</template>

<script>
    import axios from 'axios'

    export default  {
        name:'createGroup',
       data(){
            return{             
                  name_group :null,
                  visuGroup:true
            }
        }, 

        methods:{
            //fonction pour envoyer le nouveau groupe a la db
            addGroup(){  
                axios.post('http://localhost:8080/api/groupe', {
                    name_group: this.name_group
                }).then((response)=>{  
                    console.log(response)
                }) 
              //  this.$emit('fermer-bloc')
              this.visuGroup=false;
            }    
        }    
    }
</script>
<style scoped>
    div{
        float:right;
        width:85%;
        height:10em;
        background:yellow;
        margin-top:0em;
    }
</style>
