<template>
    <section class="publication">
      
     
        <!-- ici les publication general-->
    </section>
</template>
<script>
//import PostPublication from'@/components/dash/PostPublication'

export default {
    name:"mur",
    components:{
     //   PostPublication
    
    },

}
</script>
<style scoped>
.publication{
    width: 100%;
    height: 31.5em;
    border: 1px solid black;
   margin-top: 30em;
}
</style>