<template>
  <div class="hello">
    <img alt="logo groupomania" src="../assets/icon-left-font-monochrome-black.png">
  </div>
</template>

<script>
export default {
  name: 'Interface',
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
img{
  height:30em;
  margin-left:auto;
  margin-right:auto;
}
</style>
