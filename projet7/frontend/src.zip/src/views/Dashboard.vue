<template class="Dashboard">
  <div>
  
    <div class="header">
        <Entete />     
        <Profil />
        <Groupe />
        <Users/>
        <Public class="public"/> 
    </div>
    <div >
          <CreateGroup v-on:open-bloc="displayGroup" v-show="groupeDisplay" />
          <button @click="displayGroup">toto</button>
      </div>
  </div>
</template>

<script>
  import Entete from '@/components/dash/Entete.vue'
  import Profil from '@/components/dash/Profil.vue'
  import Groupe from '@/components/dash/groupe/Groupe.vue'
  import Users from '@/components/dash/Users_connected.vue'
  import Public from '@/components/dash/Publication.vue'
  import CreateGroup from '@/components/dash/groupe/CreateGroup.vue'
 // import DetailProfil from '@/components/dash/DetailProfil.vue'
 
  export default {
   name: 'Dashboard',
    components: {
      Entete,
      Profil,
      Groupe,
      Users,
      Public,
      CreateGroup
    //  DetailProfil
   },
 //action en cours le 0103
    el:'.Dashboard',
    data(){
      return{
     groupeDisplay:false,
    
      }
    },
    
    methods:{
      //Affichage du pop up creation de groupe
     displayGroup:function(){
        this.groupeDisplay= true;
      },
     closeGroup:function(){
        this.groupeDisplay=false;
      },
    },

  }
//
</script>
<style scoped>
.navLeft{
  width: 100%;
}
.public{
  width: 85%;
  float: right;
  margin-top:-67em;
}


</style>
